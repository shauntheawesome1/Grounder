import csv

with open('temps.csv', 'r') as f:
    reader = csv.reader(f)
    betaji = list(reader)

vov = []

for item in betaji:
    for jackal in item:
        vov.append(float(jackal))

print(vov)

with open('temps.txt', 'w') as filehandle:
    for juice in vov:
        filehandle.write('%s, ' % juice)
